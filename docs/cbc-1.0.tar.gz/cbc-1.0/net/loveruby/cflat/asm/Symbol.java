package net.loveruby.cflat.asm;

public interface Symbol extends Literal {
    public String name();
    public String toString();
    public String dump();
}
