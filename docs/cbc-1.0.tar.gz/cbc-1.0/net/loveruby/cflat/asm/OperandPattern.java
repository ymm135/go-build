package net.loveruby.cflat.asm;

public interface OperandPattern {
    public boolean match(Operand operand);
}
