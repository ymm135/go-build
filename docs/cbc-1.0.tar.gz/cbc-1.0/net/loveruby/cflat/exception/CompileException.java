package net.loveruby.cflat.exception;

public class CompileException extends Exception {
    public CompileException(String msg) {
        super(msg);
    }
}
