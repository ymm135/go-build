package net.loveruby.cflat.exception;

public class FileException extends CompileException {
    public FileException(String msg) {
        super(msg);
    }
}    
