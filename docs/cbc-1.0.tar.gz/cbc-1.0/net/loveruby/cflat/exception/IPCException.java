package net.loveruby.cflat.exception;

public class IPCException extends CompileException {
    public IPCException(String msg) {
        super(msg);
    }
}
