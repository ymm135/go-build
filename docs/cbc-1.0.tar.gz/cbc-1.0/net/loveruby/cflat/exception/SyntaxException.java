package net.loveruby.cflat.exception;

public class SyntaxException extends CompileException {
    public SyntaxException(String msg) {
        super(msg);
    }
}
