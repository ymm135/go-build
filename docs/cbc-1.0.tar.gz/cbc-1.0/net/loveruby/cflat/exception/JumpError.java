package net.loveruby.cflat.exception;

public class JumpError extends SemanticError {
    public JumpError(String msg) {
        super(msg);
    }
}
