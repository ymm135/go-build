package net.loveruby.cflat.exception;

public class OptionParseError extends Error {
    public OptionParseError(String msg) {
        super(msg);
    }
}
