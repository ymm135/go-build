package net.loveruby.cflat.exception;

public class SemanticError extends Error {
    public SemanticError(String msg) {
        super(msg);
    }
}
