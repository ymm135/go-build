package net.loveruby.cflat.exception;

public class SemanticException extends CompileException {
    public SemanticException(String msg) {
        super(msg);
    }
}
