package net.loveruby.cflat.ir;

public interface Dumpable {
    void dump(Dumper d);
}
