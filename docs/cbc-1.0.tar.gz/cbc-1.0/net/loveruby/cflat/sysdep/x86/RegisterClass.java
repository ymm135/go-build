package net.loveruby.cflat.sysdep.x86;

enum RegisterClass {
    AX, BX, CX, DX, SI, DI, SP, BP;
}
