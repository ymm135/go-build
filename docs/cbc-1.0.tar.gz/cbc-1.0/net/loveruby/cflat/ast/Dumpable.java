package net.loveruby.cflat.ast;

public interface Dumpable {
    void dump(Dumper d);
}
