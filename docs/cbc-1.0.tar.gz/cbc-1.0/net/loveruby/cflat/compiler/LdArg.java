package net.loveruby.cflat.compiler;

interface LdArg {
    String toString();
    boolean isSourceFile();
}
